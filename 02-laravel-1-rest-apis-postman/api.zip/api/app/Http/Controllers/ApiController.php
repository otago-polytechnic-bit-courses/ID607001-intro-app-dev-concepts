<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Student;

class ApiController extends Controller
{
    public function createStudent(Request $request)
    {
        $student = new Student;
        $student->first_name = $request->first_name;
        $student->last_name = $request->last_name;
        $student->phone_number = $request->phone_number;
        $student->email_address = $request->email_address;
        $student->save();
        return response()->json(["message" => "Student created."], 201);
    }

    public function updateStudent(Request $request, $id)
    {
        if (Student::where('id', $id)->exists()) {
            $student = Student::find($id);
            $student->first_name = is_null($request->first_name) ? $student->first_name : $request->first_name;
            $student->last_name = is_null($request->last_name) ? $student->last_name : $request->last_name;
            $student->phone_number = is_null($request->phone_number) ? $student->phone_number : $request->phone_number;
            $student->email_address = is_null($request->email_address) ? $student->email_address : $request->email_address;
            $student->save();
            return response()->json(["message" => "Student updated."], 200);
        } else {
            return response()->json(["message" => "Student not found."], 404);
        }
    }

    public function deleteStudent($id)
    {
        if (Student::where('id', $id)->exists()) {
            $student = Student::find($id);
            $student->delete();
            return response()->json(["message" => "Student deleted."], 202);
        } else {
            return response()->json(["message" => "Student not found."], 404);
        }
    }

    public function getAllStudents()
    {
        $students = Student::get()->toJson(JSON_PRETTY_PRINT);
        return response($students, 200);
    }
    
    public function getStudent($id)
    {
        if (Student::where('id', $id)->exists()) {
            $student = Student::where('id', $id)->get()->toJson(JSON_PRETTY_PRINT);
            return response($student, 200);
        } else {
            return response()->json(["message" => "Student not found."], 404);
        }
    }
}